$(".mytop .mynav .toggle").click(function(){
    $(this).addClass("active").siblings(".menu").toggle();
})