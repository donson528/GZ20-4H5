<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>

<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>


    $(document).ready(function () {

        $('.flexslider').flexslider({

            directionNav: true,

            pauseOnAction: false

        });

    });


